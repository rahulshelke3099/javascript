var person = {
    pname: "Riya",
    page: 22,
    getName: function () {
        return this.pname;
    },
    getAge: function () {
        return this.page;
    }
};
console.log("name is " + person.getName());
console.log("age is  " + person.getAge());
