class Employee
{
    empId:number;
    empName:string;
    empSal:number;

   constructor(id:number,name:string,sal:number)
    {
        this.empId=id;
        this.empName=name;
        this.empSal=sal;
    }

    display():void
    {
        console.log("emp name "+this.empName +" emp id "+this.empId+"emp salary "+this.empSal);
    }
}
class Manager extends Employee
{

    designation:string;

    constructor(id:number,name:string,sal:number,desig:string)
    {
        super(id,name,sal);
        this.designation=desig;
    }
}

var managerobj=new Manager(10,"rahul",100000,"HR");
managerobj.display();