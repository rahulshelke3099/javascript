"use strict";
let sname = "Hello";
var data = "data";
console.log("let sname=" + sname);
console.log("var data" + data);
