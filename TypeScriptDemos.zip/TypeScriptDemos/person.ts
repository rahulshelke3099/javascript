interface Person
{
    pname:string;
    page:number;

    getName():string;
    getAge():number;
}

var person:Person={
    pname:"Riya",
    page:22,
    getName():string{
        return this.pname;
    },
    getAge():number
    {
        return this.page;
    }
}
console.log("name is "+person.getName());
console.log("age is  "+person.getAge());