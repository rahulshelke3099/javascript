"use strict";
class Hello {
    constructor(msg) {
        this.message = msg;
    }
    getMessage() {
        return this.message;
    }
}
var obj = new Hello("Welcome");
console.log("Hii All " + obj.getMessage());
