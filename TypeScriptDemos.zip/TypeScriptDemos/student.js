"use strict";
exports.__esModule = true;
var Student = /** @class */ (function () {
    function Student(sname, sage, smarks) {
        this.sname = sname;
        this.sage = sage;
        this.smarks = smarks;
    }
    Student.prototype.getMarks = function () {
        return this.smarks;
    };
    Student.prototype.getAge = function () {
        return this.sage;
    };
    Student.prototype.getName = function () {
        return this.sname;
    };
    return Student;
}());
exports.Student = Student;
