let sname:string= "Hello";
var data:string = "data";
console.log("let sname="+sname)
console.log("var data"+data)