"use strict";
exports.__esModule = true;
var student_1 = require("./student");
var stu = new student_1.Student("rahul", 34, 90);
console.log("Name is " + stu.getName());
console.log("age is " + stu.getAge());
console.log("marks " + stu.getMarks());
var stuarr = new Array();
var stu1 = new student_1.Student("chinmay", 12, 23);
var stu2 = new student_1.Student("rahul", 23, 56);
stuarr.push(stu1);
stuarr.push(stu2);
for (var _i = 0, stuarr_1 = stuarr; _i < stuarr_1.length; _i++) {
    stu = stuarr_1[_i];
    console.log("Name is " + stu.getName());
    console.log("age is " + stu.getAge());
    console.log("marks " + stu.getMarks());
}
