import {Student} from './student';

var stu=new Student("rahul",34,90);
console.log("Name is "+stu.getName());
console.log("age is "+stu.getAge());
console.log("marks "+stu.getMarks());

var stuarr:Student[]=new Array<Student>();

var stu1=new Student("chinmay",12,23);
var stu2=new Student("pushpak",23,56);

stuarr.push(stu1);
stuarr.push(stu2);

for(stu of stuarr)
{
console.log("Name is "+stu.getName());
console.log("age is "+stu.getAge());
console.log("marks "+stu.getMarks());
}