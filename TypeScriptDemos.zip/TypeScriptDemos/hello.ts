class Hello
{
  message:string;

  constructor(msg :string)
  {
      this.message=msg;
  }
  getMessage():string
  {
    return this.message;
  }
}
var obj=new Hello("Welcome");
console.log("Hii All " +obj.getMessage());