import {Injectable} from '@angular/core';
import {Product} from '../product';
import{Subject} from 'rxjs';



@Injectable()
export class CartService
{
cart:Product[];

myCart:string;
product:Product[]=[];

private cartSource=new Subject<string>();

cartBroadCaster=this.cartSource.asObservable();

constructor()
{

     if(this.myCart)
    {
        this.cart=JSON.parse(this.myCart);
    }
    else
    {
        this.cart=new Array<Product>();
    }
}

addToCart(product: Product):void{

    this.cart=this.cart.concat(product)
    console.log('Added to the cart '+product.name);


    this.myCart=JSON.stringify(this.cart);

    // Notify to the observers
    this.cartSource.next(this.myCart);
}
getCartDetails():Product[]
{
    return this.cart;
}


}