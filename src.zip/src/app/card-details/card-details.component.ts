import { Component } from '@angular/core';
import {Product} from '../product';
import { CartService } from './card.service';
@Component({
  selector: 'app-card-details',
  templateUrl: './card-details.component.html',
  styleUrls: ['./card-details.component.css']
})

export class CardDetailsComponent  {

cardProducts:Product[]=[];
constructor(private cartService:CartService)
{

  this.cartService.cartBroadCaster.subscribe(res=>{
    alert(res);
    this.cardProducts=JSON.parse(res);
  })
 this.cardProducts=cartService.getCartDetails();

}
  
}
