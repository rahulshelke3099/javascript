import {Injectable} from '@angular/core';
import {Product} from './product';
@Injectable()
export class ProductService
{
   products : Product[];
   
   constructor()
   {
       let p1=new Product(1,"oneplus","./assets/images/1.jpg",37999,"Mobile");
       let p2=new Product(2,"Moto g5 plus","./assets/images/2.jpg",242424,"Mobile");
       let p3=new Product(3,"Nokia 6","./assets/images/3.jpg",4,"Mobile");
       let p4=new Product(4,"Samasung Galaxy Note 8","./assets/images/4.jpg",4452,"Mobile");
       let p5=new Product(5,"Apple Iphone 8","./assets/images/5.jpg",5552,"Mobile");
       let p6=new Product(6,"Dell Laptop","./assets/images/6.jpg",7785,"Laptop");
       let p7=new Product(7,"Canon DSLR","./assets/images/7.jpg",785,"Camera");
       let p8=new Product(8,"HP Printer","./assets/images/8.jpg",7757,"Printer");
       let p9=new Product(9,"Apple iPad","./assets/images/9.jpg",7777,"Tab");


       this.products=new Array<Product>();

       this.products.push(p1);
       this.products.push(p2);
       this.products.push(p3);
       this.products.push(p4);
       this.products.push(p5);
       this.products.push(p6);
       this.products.push(p7);
       this.products.push(p8);
       this.products.push(p9);

   }

   getProdcuts():Array<Product>
   {
    return this.products;
   }
   addToCart(product:Product):void{
       alert(product.name+ " "+product.price);
   }

}