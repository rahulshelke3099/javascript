import {Component, Input} from '@angular/core';

@Component(
{
    selector:"hello",
    template:'<h2>{{name}}{{msg}}</h2>',
})

export class HelloComponent
{
    name:string;

    @Input()
    msg:string;

    constructor()
    {
        this.name="rahul";
    }
}