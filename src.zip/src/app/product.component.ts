import {Component} from '@angular/core';
import {Product} from './product'
import {ProductService} from './product.service'
import { CartService } from './card-details/card.service';
@Component({

    selector:"product",
    template:`<html>
    <body>
    <div align="center">
    <h1>Enter search string::</h1>
    <input type="text" (blur)="doSearch($event.target.value)"/>
     <table align="center"  border=2>
     <caption><h1>Product Details</h1></caption>
     <tr>
        <th>Product Id</th>
        <th>Product Name</th>
        <th>Product Image</th>
        <th>Product Price</th>
        <th>Product Category</th>
        <th colspan="3">Action</th>
    </tr>
    <tr *ngFor="let product of products">
    <td>{{product.id}}</td>
    <td><a href="{{product.id}}"> {{product.name}}</a></td>
    <td><img [src]="product.imgPath" height="50" width="50"/></td>
    <td>{{product.price}}</td>
    <td>{{product.category}}</td>
    
    <td><button  (click)="addToCart(product)" >Add To Cart</button></td>
    <td><button (click)="showDetails(product)" *ngIf="isAdmin">Details</button></td>
    </tr>
    </table>
    </div>
    </body>
    </html>`,
    providers:[ProductService]
})

export class ProductComponent
{
    products:Product[];
    
    isAdmin:boolean=true;
    // injecting service in the component
    constructor(private productSerivce:ProductService,private cartService:CartService)
    {

        this.products=productSerivce.getProdcuts();
    }

    showDetails(product:Product):void
    {
        alert(product.name+" "+product.price)
    }
    doSearch(searchstr:string):void
    {
        var prodNames:string[]=new Array<string>();

        for(var i in this.products)
        {
            if(this.products[i].name.toLowerCase().startsWith(searchstr.toLowerCase()))
            {
                    prodNames.push(this.products[i].name);
                    alert(prodNames);
            }
        }
    }
    addToCart(product:Product):void{

        this.cartService.addToCart(product);
    }


}