import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-greet-component',
  templateUrl: './greet-component.component.html',
  styleUrls: ['./greet-component.component.css']
})
export class GreetComponentComponent  {

  message:string;
  constructor() {
    this.message="Welcome to Angular";
   }

}
