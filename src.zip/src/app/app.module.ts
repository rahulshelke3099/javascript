import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GreetComponentComponent } from './greet-component/greet-component.component';
import { HelloComponent } from './hello.component';
import { ProductComponent } from './product.component';

import { MenuComponent } from './menu/menu.component';
import { MenuService } from './menu/menu.service';
import { CardDetailsComponent } from './card-details/card-details.component';
import { CartService } from './card-details/card.service';


@NgModule({
  declarations: [
    AppComponent,
    GreetComponentComponent,
    HelloComponent,
    ProductComponent,
    MenuComponent,
    CardDetailsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [MenuService,CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
